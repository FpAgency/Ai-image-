import "./App.css";
import ImageGenerator from "./components/ImageGenerator/ImageGenerator";

function App() {
    return (
        <div className="App">
            <ImageGenerator />
        </div>
    );
}

export default App;
