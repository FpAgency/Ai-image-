# AI Image Generator
Turn words into stunning AI-generated Art and drawings instantly. Enter a prompt- AI art generator brings your ideas to life!

## TechStacks
- React js
- javascript
- html
- css
- eden ai api

## Demo Video

<img src="https://github.com/khan-mujeeb/AI-Image-Generator/assets/89351750/32c723cc-6c07-417e-aea9-068cccce2337" height="500" width="1080" />

## ScreenShot

<div>
  
<img src="https://github.com/khan-mujeeb/AI-Image-Generator/assets/89351750/30237bcd-2c23-478b-a391-e037f6d3d1aa" width="540" height="250"/>


<br><br>

<img src="https://github.com/khan-mujeeb/AI-Image-Generator/assets/89351750/8b8e9170-3154-45c2-9881-c03f4285467b" width="540" height="250"/>

</div>

## Features
- Create AI generated Image with a single click
- Download your hd image for free

## ⚙ How it works ?!
User need to enter a prompt, AI image generator automatically creates a ai art 



